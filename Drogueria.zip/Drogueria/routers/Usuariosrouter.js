const express = require('express');
const UsuariosSquema = require('../models/Usuarios');
const Usuariosrouter = express.Router();

//Listar Usuarios
Usuariosrouter.get("/",(req,res)=>{
    UsuariosSquema
        .find()
        .then((data)=>res.json({Usuarios: data}))
        .catch((error) => res.json({message: error}));
})
//buscar un usuario
Usuariosrouter.get("/:id",(req,res)=>{
    UsuariosSquema
        .findById({_id: req.params.id})
        .then((data)=>res.json(data))
        .catch((error) => res.json({message: error}));
})

// crear usuarios
Usuariosrouter.post("/",(req,res)=>{
    const usuarios = UsuariosSquema(req.body);

    usuarios.save()
            .then((data)=>res.json(data))
            .catch((error) => res.json({message: error}));
})

/// actualizar
Usuariosrouter.patch("/:id",(req,res)=>{
    UsuariosSquema.updateOne(
        {
            _id: req.params.id,
            
        $set:{
            cod_paciente: req.body.cod_paciente,
            documento:req.body.documento,
            tipo_Documento:req.body.documento,
            nombre: req.body.nombre,
            edad : req.body.edad,
            telefono: req.body.telefono,
            direccion: req.body.direccion,
            clave: req.body.clave,
        }
    }
    )
    .then((data)=>res.json(data))
    .catch((error) => res.json({message: error}));
})
/// eliminar
Usuariosrouter.delete("/:id ",(req,res)=>{
    UsuariosSquema.deleteOne(
        {
            _id: req.params.id
            
        }
    )
    .then((data)=>res.json(data))
    .catch((error) => res.json({message: error}));
})

module.exports = Usuariosrouter;