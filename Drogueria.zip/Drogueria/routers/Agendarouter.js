const express = require('express');
const AgendaSquema = require('../models/Agendas');
const Agendarouter = express.Router();

//Listar Usuarios
Agendarouter.get("/",(req,res)=>{
    AgendaSquema
        .find()
        .then((data)=>res.json({Usuarios: data}))
        .catch((error) => res.json({message: error}));
})
//buscar un usuario
Agendarouter.get("/:id",(req,res)=>{
    AgendaSquema
        .findById({_id: req.params.id})
        .then((data)=>res.json(data))
        .catch((error) => res.json({message: error}));
})

// crear usuarios
Agendarouter.post("/",(req,res)=>{
    const usuarios = AgendaSquema(req.body);

    usuarios.save()
            .then((data)=>res.json(data))
            .catch((error) => res.json({message: error}));
})

/// actualizar
Agendarouter.patch("/:id",(req,res)=>{
    AgendaSquema.updateOne(
        {
            _id: req.params.id,
            
        $set:{
            cod_paciente: req.body.cod_paciente,
            documento:req.body.documento,
            tipo_Documento:req.body.documento,
            nombre: req.body.nombre,
            edad : req.body.edad,
            telefono: req.body.telefono,
            direccion: req.body.direccion,
            clave: req.body.clave,
        }
    }
    )
    .then((data)=>res.json(data))
    .catch((error) => res.json({message: error}));
})
/// eliminar
Agendarouter.delete("/:id ",(req,res)=>{
    AgendaSquema.deleteOne(
        {
            _id: req.params.id
            
        }
    )
    .then((data)=>res.json(data))
    .catch((error) => res.json({message: error}));
})

module.exports = Agendarouter;