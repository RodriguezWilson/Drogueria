const express = require('express');
const FacturasSquema = require('../models/Facturas');
const Facturasrouter = express.Router();

//Listar Usuarios
Facturasrouter.get("/",(req,res)=>{
    FacturasSquema
        .find()
        .then((data)=>res.json({Usuarios: data}))
        .catch((error) => res.json({message: error}));
})
//buscar un usuario
Facturasrouter.get("/:id",(req,res)=>{
    FacturasSquema
        .findById({_id: req.params.id})
        .then((data)=>res.json(data))
        .catch((error) => res.json({message: error}));
})

// crear usuarios
Facturasrouter.post("/",(req,res)=>{
    const usuarios = FacturasSquema(req.body);

    usuarios.save()
            .then((data)=>res.json(data))
            .catch((error) => res.json({message: error}));
})

/// actualizar
Facturasrouter.patch("/:id",(req,res)=>{
    FacturasSquema.updateOne(
        {
            _id: req.params.id,
            
        $set:{
            cod_paciente: req.body.cod_paciente,
            documento:req.body.documento,
            tipo_Documento:req.body.documento,
            nombre: req.body.nombre,
            edad : req.body.edad,
            telefono: req.body.telefono,
            direccion: req.body.direccion,
            clave: req.body.clave,
        }
    }
    )
    .then((data)=>res.json(data))
    .catch((error) => res.json({message: error}));
})
/// eliminar
Facturasrouter.delete("/:id ",(req,res)=>{
    FacturasSquema.deleteOne(
        {
            _id: req.params.id
            
        }
    )
    .then((data)=>res.json(data))
    .catch((error) => res.json({message: error}));
})

module.exports = Facturasrouter;