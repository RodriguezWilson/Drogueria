const express = require('express');
const MedicamentosSquema = require('../models/Medicamentos');
const Medicamentosrouter = express.Router();

//Listar Usuarios
Medicamentosrouter.get("/",(req,res)=>{
    MedicamentosSquema
        .find()
        .then((data)=>res.json({Usuarios: data}))
        .catch((error) => res.json({message: error}));
})
//buscar un usuario
Medicamentosrouter.get("/:id",(req,res)=>{
    MedicamentosSquema
        .findById({_id: req.params.id})
        .then((data)=>res.json(data))
        .catch((error) => res.json({message: error}));
})

// crear usuarios
Medicamentosrouter.post("/",(req,res)=>{
    const usuarios = MedicamentosSquema(req.body);

    usuarios.save()
            .then((data)=>res.json(data))
            .catch((error) => res.json({message: error}));
})

/// actualizar
Medicamentosrouter.patch("/:id",(req,res)=>{
    MedicamentosSquema.updateOne(
        {
            _id: req.params.id,
            
        $set:{
            cod_paciente: req.body.cod_paciente,
            documento:req.body.documento,
            tipo_Documento:req.body.documento,
            nombre: req.body.nombre,
            edad : req.body.edad,
            telefono: req.body.telefono,
            direccion: req.body.direccion,
            clave: req.body.clave,
        }
    }
    )
    .then((data)=>res.json(data))
    .catch((error) => res.json({message: error}));
})
/// eliminar
Medicamentosrouter.delete("/:id ",(req,res)=>{
    MedicamentosSquema.deleteOne(
        {
            _id: req.params.id
            
        }
    )
    .then((data)=>res.json(data))
    .catch((error) => res.json({message: error}));
})

module.exports = Medicamentosrouter;