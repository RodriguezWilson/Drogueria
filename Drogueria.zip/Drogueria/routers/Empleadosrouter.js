const express = require('express');
const EmpleadoSquema = require('../models/Empleado');
const Empleadosrouter = express.Router();

//Listar 
Empleadosrouter.get("/",(req,res)=>{
    EmpleadoSquema
        .find()
        .then((data)=>res.json({Usuarios: data}))
        .catch((error) => res.json({message: error}));
})
//buscar 
Empleadosrouter.get("/:id",(req,res)=>{
    EmpleadoSquema
        .findById({_id: req.params.id})
        .then((data)=>res.json(data))
        .catch((error) => res.json({message: error}));
})

// crear
Empleadosrouter.post("/",(req,res)=>{
    const empleados = EmpleadoSquema(req.body);

    empleados.save()
            .then((data)=>res.json(data))
            .catch((error) => res.json({message: error}));
})

/// actualizar
Empleadosrouter.patch("/:id",(req,res)=>{
    EmpleadoSquema.updateOne(
        {
            _id: req.params.id,
            
        $set:{
            cod_paciente: req.body.cod_paciente,
            documento:req.body.documento,
            tipo_Documento:req.body.documento,
            nombre: req.body.nombre,
            edad : req.body.edad,
            telefono: req.body.telefono,
            direccion: req.body.direccion,
            clave: req.body.clave,
        }
    }
    )
    .then((data)=>res.json(data))
    .catch((error) => res.json({message: error}));
})
/// eliminar
Empleadosrouter.delete("/:id ",(req,res)=>{
    EmpleadoSquema.deleteOne(
        {
            _id: req.params.id
            
        }
    )
    .then((data)=>res.json(data))
    .catch((error) => res.json({message: error}));
})

module.exports = Empleadosrouter;