const express = require('express');
const cors = require('cors');
//const bodyParse = require('body-parse');
const Usuariosrouter=require('./routers/Usuariosrouter');
const Empleadorouter = require('./routers/Empleadosrouter');
const app = express();
app.use(cors());
app.use(express.json());
app.use("/usuarios",Usuariosrouter)
app.use("/empleado",Empleadorouter)


app.get("/",(req,res)=>{
         res.json({data:"hola con patch"})
     })



const PORT = process.env.PORT || 9000;
app.listen(PORT)
