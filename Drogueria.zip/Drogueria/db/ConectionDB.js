const {request} = require("express");
const mongoose = require('mongoose');

mongoose.connect(
    //"mongodb+srv://root:Drogueria08172007@cluster0.n1xtwra.mongodb.net/?retryWrites=true&w=majority"
    "mongodb://root:Drogueria08172007@ac-qpkea3t-shard-00-00.n1xtwra.mongodb.net:27017,ac-qpkea3t-shard-00-01.n1xtwra.mongodb.net:27017,ac-qpkea3t-shard-00-02.n1xtwra.mongodb.net:27017/?ssl=true&replicaSet=atlas-6no3tb-shard-0&authSource=admin&retryWrites=true&w=majority"
    ).
    then(event=> console.log("conectado a mongo porfin ;)")).
    catch((err)=> console.log(err));


module.exports = mongoose;