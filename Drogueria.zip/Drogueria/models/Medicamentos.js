const mongoose = require('../db/ConectionDB');

const MedicamentosSquema = mongoose.Schema({
    cod_Medicamentos:{
        type:Number,
        require:true,
        unique:true
    },
    nombre:{
        type:String,
        required:true,
    },
    proveedor:{
        type:String,
        required:true,
    },
    tipo:{
        type:String,
        required:true,
    },
    precio:{
        type:Number,
        required:true,
    },
    imagen:{
        type:String,
        required:true,
    },
    estado:{
        type:BinData,
        required:true,
    },
    cod_Usuario:{
        type:String,
        require:true,
    }
},
    {
        collection: 'Medicamentos',
        versionKey: false
    });

module.exports = mongoose.model('Medicamentos',MedicamentosSquema);