const mongoose = require('../db/ConectionDB');

const EmpleadoSquema = mongoose.Schema({
    cod_Usuario:{
        type:String,
        require:true,
        unique:true
    },
    documento:{
        type:String,
        required:true,
    },
    nombre:{
        type:String,
        required:true,
    },
    clave:{
        type:String,
        required:true
    },
    rol:{
        type:String,
        required:true
    },
    
},{
    collection: 'Empleado',
    versionKey: false
});

module.exports = mongoose.model('Empleado',EmpleadoSquema);