const mongoose = require('../db/ConectionDB');

const AgendaSquema = mongoose.Schema({
    Fecha_Cita:{
        type:Date,
        require:true
    },
    Cod_paciente:{
        type:String,
        required:true,
    },
    Hora_Cita:{
        type:String,
        required:true,
    },
    Estado:{
        type:String,
        required:true,
    },
    cod_Usuario:{
        type:String,
        require:true,
    }
    
},{
    collection: 'Agenda',
    versionKey: false
});

module.exports = mongoose.model('Agenda',AgendaSquema);