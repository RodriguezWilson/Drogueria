const mongoose = require('../db/ConectionDB');

const UsuariosSquema = mongoose.Schema({
    cod_paciente:{
        type:String,
        require:true,
        unique:true
    },
    documento:{
        type:Number,
        required:true,
    },
    tipo_Documento:{
        type:String,
        required:true,
    },
    nombre:{
        type:String,
        required:true,
    },
    edad:{
        type:Number,
        required:true,
    },
    telefono:{
        type:String,
        required:true,
    },
    direccion:{
        type:String,
        required:true,
    },
    clave:{
        type:String,
        required:true
    },
    
},{
    collection: 'Usuarios',
    versionKey: false
});

module.exports = mongoose.model('Usuarios',UsuariosSquema);