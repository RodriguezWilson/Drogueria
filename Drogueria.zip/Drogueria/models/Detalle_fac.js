const mongoose = require('../db/ConectionDB');

const DetFactura = mongoose.Schema({
    Nro_Factura:{
        type:String,
        require:true,
    },
    Fecha_Factura:{
        type:Date,
        require:true,
        
    },
    Cod_Medicamentos:{
        type:int,
        require:true,
    },
    Cantidad:{
        type:int,
        require:true,
    },
    Vlr_Unitario:{
        type:int,
        require:true,
    },
    Vlr_Total:{
        type:int,
        require:true,
    },
    cod_Usuario:{
        type:int,
        require:true,
    }


})