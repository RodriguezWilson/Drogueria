const mongoose = require('../db/ConectionDB');

const FacturasSquema = mongoose.Schema({
    Nro_Factura:{
        type:String,
        require:true,
        unique:true
    },
    Fecha_Factura:{
        type:Date,
        require:true,
        
    },
    cod_paciente:{
        type:String,
        require:true,
    },
    Foma_Pago:{
        type:String,
        require:true,
    },
    Fecha_Envio:{
        type:Date,
        require:true, 
    },
    Origen:{
        type:String,
        require:true,
    },
    cod_Usuario:{
        type:String,
        require:true,
    }

},{
    collection: 'Facturas',
    versionKey: false
});

module.exports = mongoose.model('Facturas',FacturasSquema);